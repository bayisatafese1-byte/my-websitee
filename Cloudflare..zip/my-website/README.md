# My Business Website

A real, working, responsive business website. No server and no installation needed.

## What works
- Product list, shopping cart with + and - buttons, automatic total
- Customer sends the order to you on WhatsApp or by email, with name, phone and address
- Works on phones, tablets and computers; light and dark mode
- Cart is remembered if the customer refreshes the page (after the site is online)

## Files
- index.html : the page
- style.css  : colors and layout
- script.js  : your business info, products, and the working code

## Setup (5 minutes)
1. Open script.js in Notepad or VS Code.
2. Edit only the BUSINESS and PRODUCTS parts at the top.
   - whatsapp: country code + number, no plus sign (example: 251911223344)
3. Save, then double-click index.html to test it in your browser.
4. Upload the whole folder to Cloudflare Pages or GitHub Pages.

## Security notes
- Text typed by visitors is shown with textContent, never innerHTML.
- Do not put passwords or private keys in these files.

Author: Bayisa Tafese

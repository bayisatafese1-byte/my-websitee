/* =====================================================
   STEP 1: EDIT THIS PART ONLY (your business information)
   ===================================================== */
var BUSINESS = {
  name: "Bayisa Tafese",
  headline: "Fresh products, delivered to you",
  tagline: "Order online in two minutes. We confirm every order by phone.",
  about: "We are a local business. Write two or three sentences here about who you are, how long you have worked, and why customers trust you.",
  phone: "+251906619022",          // shown on the website
  email: "bayisatafese1@gmail.com",     // orders by email arrive here
  whatsapp: "251906619022",        // WhatsApp number: country code + number, NO plus sign, NO spaces
  address: "Your city, Ethiopia",
  hours: "Monday - Saturday, 8:00 - 18:00",
  currency: "ETB"
};

// Your products. To add one, copy a line and change it. "id" must be different for each product.
var PRODUCTS = [
  { id: "p1", name: "Product One",   description: "Write a short description here.", price: 400 },
  { id: "p2", name: "Product Two",   description: "Write a short description here.", price: 450 },
  { id: "p3", name: "Product Three", description: "Write a short description here.", price: 500 }
];
/* =====================================================
   END OF THE PART YOU EDIT. Below is the working code.
   ===================================================== */

(function () {
  var cart = {};   // { productId: quantity }
  var $ = function (id) { return document.getElementById(id); };

  // ---- Fill in business info (textContent = safe, never innerHTML) ----
  document.title = BUSINESS.name;
  document.querySelectorAll("[data-biz]").forEach(function (el) {
    var v = BUSINESS[el.getAttribute("data-biz")];
    if (v) el.textContent = v;
  });
  $("phoneLink").href = "tel:" + BUSINESS.phone.replace(/[^0-9+]/g, "");
  $("emailLink").href = "mailto:" + BUSINESS.email;
  $("year").textContent = new Date().getFullYear();

  // ---- Mobile menu ----
  var btn = $("menuBtn"), nav = $("nav");
  btn.addEventListener("click", function () {
    var open = nav.classList.toggle("open");
    btn.setAttribute("aria-expanded", open);
  });
  nav.addEventListener("click", function (e) {
    if (e.target.tagName === "A") { nav.classList.remove("open"); btn.setAttribute("aria-expanded", false); }
  });

  // ---- Helpers ----
  function money(n) { return n.toLocaleString("en-US") + " " + BUSINESS.currency; }
  function find(id) { return PRODUCTS.filter(function (p) { return p.id === id; })[0]; }
  function el(tag, text, cls) {
    var e = document.createElement(tag);
    if (text !== undefined) e.textContent = text;
    if (cls) e.className = cls;
    return e;
  }

  // ---- Save / load cart (works on real hosting; wrapped in try/catch) ----
  function save() { try { localStorage.setItem("cart", JSON.stringify(cart)); } catch (e) {} }
  function load() {
    try {
      var data = JSON.parse(localStorage.getItem("cart") || "{}");
      Object.keys(data).forEach(function (id) {
        var q = parseInt(data[id], 10);
        if (find(id) && q > 0) cart[id] = q;
      });
    } catch (e) {}
  }

  // ---- Show products ----
  function renderProducts() {
    var grid = $("productGrid");
    grid.textContent = "";
    PRODUCTS.forEach(function (p) {
      var card = el("article", undefined, "card");
      card.appendChild(el("div", undefined, "swatch"));
      card.appendChild(el("h3", p.name));
      card.appendChild(el("p", p.description));
      card.appendChild(el("div", money(p.price), "price"));
      var add = el("button", "Add", "btn small");
      add.type = "button";
      add.addEventListener("click", function () { cart[p.id] = (cart[p.id] || 0) + 1; update(); });
      card.appendChild(add);
      grid.appendChild(card);
    });
  }

  // ---- Show cart ----
  function renderCart() {
    var box = $("cartBox"), total = 0, count = 0;
    box.textContent = "";
    var ids = Object.keys(cart);
    if (ids.length === 0) box.appendChild(el("p", "Your order is empty. Add products above.", "empty"));
    ids.forEach(function (id) {
      var p = find(id), q = cart[id];
      total += p.price * q; count += q;
      var row = el("div", undefined, "line");
      row.appendChild(el("span", p.name + " (" + money(p.price) + ")"));
      var qty = el("div", undefined, "qty");
      var minus = el("button", "−"); minus.type = "button"; minus.setAttribute("aria-label", "Remove one " + p.name);
      var plus = el("button", "+");  plus.type = "button";  plus.setAttribute("aria-label", "Add one " + p.name);
      minus.addEventListener("click", function () { cart[id]--; if (cart[id] <= 0) delete cart[id]; update(); });
      plus.addEventListener("click", function () { cart[id]++; update(); });
      qty.appendChild(minus); qty.appendChild(el("span", String(q))); qty.appendChild(plus);
      row.appendChild(qty);
      box.appendChild(row);
    });
    $("total").textContent = money(total);
    $("cartCount").textContent = count;
  }

  function update() { renderCart(); save(); $("status").textContent = ""; }

  $("clearCart").addEventListener("click", function () { cart = {}; update(); });

  // ---- Build the order message and check the form ----
  function buildOrder() {
    var name = $("cName").value.trim();
    var phone = $("cPhone").value.trim();
    var address = $("cAddress").value.trim();
    var s = $("status");
    if (Object.keys(cart).length === 0) { s.textContent = "Please add at least one product."; return null; }
    if (name.length < 2) { s.textContent = "Please type your name."; $("cName").focus(); return null; }
    if (!/^[0-9+\s-]{9,16}$/.test(phone)) { s.textContent = "Please type a valid phone number."; $("cPhone").focus(); return null; }
    if (address.length < 3) { s.textContent = "Please type your delivery address."; $("cAddress").focus(); return null; }

    var total = 0;
    var lines = Object.keys(cart).map(function (id) {
      var p = find(id), q = cart[id];
      total += p.price * q;
      return "- " + p.name + " x" + q + " = " + money(p.price * q);
    });
    return "New order for " + BUSINESS.name + "\n\n" + lines.join("\n") +
      "\n\nTotal: " + money(total) +
      "\n\nName: " + name + "\nPhone: " + phone + "\nAddress: " + address;
  }

  function afterSend() {
    $("status").textContent = "Your order message is ready. Press send in the app that opened.";
  }

  $("sendWA").addEventListener("click", function () {
    var msg = buildOrder(); if (!msg) return;
    window.open("https://wa.me/" + BUSINESS.whatsapp.replace(/[^0-9]/g, "") + "?text=" + encodeURIComponent(msg), "_blank", "noopener");
    afterSend();
  });

  $("sendMail").addEventListener("click", function () {
    var msg = buildOrder(); if (!msg) return;
    window.location.href = "mailto:" + BUSINESS.email + "?subject=" + encodeURIComponent("New order - " + BUSINESS.name) + "&body=" + encodeURIComponent(msg);
    afterSend();
  });

  // ---- Start ----
  load();
  renderProducts();
  renderCart();
})();
